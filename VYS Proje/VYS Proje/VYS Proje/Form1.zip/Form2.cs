﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.Odbc;

namespace VYS_Proje
{
    public partial class Form2 : Form
    {
        public Form2()
        {
            InitializeComponent();
        }
        OdbcConnection connection = new OdbcConnection("Host=localhost;User=postgres;Password=123123;Database=proje");
        private void Form2_Load(object sender, EventArgs e)
        {

        }

        private void maskedTextBox2_MaskInputRejected(object sender, MaskInputRejectedEventArgs e)
        {

        }

        private void btnEkle_Click(object sender, EventArgs e)
        {
            string ad = txtAd.Text;
            string soyad = txtSoyad.Text;
            string eposta = txtEposta.Text;
            string adres = txtAdres.Text;
            string saglik_durumu = txtSaglikDurumu.Text;
            string telefon = txtTelefon.Text;

            try
            {
                connection.Open();

                string query = "INSERT INTO kisi (ad, soyad, eposta, adres, saglik_durumu, telefon) VALUES (@ad, @soyad, @eposta, @adres, @saglik_durumu, @telefon)";

                OdbcCommand command = new OdbcCommand(query, connection);
                {
                    command.Parameters.AddWithValue("@ad", ad);
                    command.Parameters.AddWithValue("@soyad", soyad);
                    command.Parameters.AddWithValue("@eposta", eposta);
                    command.Parameters.AddWithValue("@adres", adres);
                    command.Parameters.AddWithValue("@saglik_durumu", saglik_durumu);
                    command.Parameters.AddWithValue("@telefon", telefon);

                    int result = command.ExecuteNonQuery();

                    if (result > 0)
                    {
                        MessageBox.Show("Kayıt başarıyla eklendi.", "Bilgi", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    }
                    else
                    {
                        MessageBox.Show("Kayıt eklenemedi.", "Hata", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Bir hata oluştu: {ex.Message}", "Hata", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }                  
    }
}
